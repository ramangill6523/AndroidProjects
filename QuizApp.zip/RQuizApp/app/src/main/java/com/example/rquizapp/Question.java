package com.example.rquizapp;

public class Question {
    int question;
    Boolean answer;

    public Question(int question, Boolean answer) {
        this.question = question;
        this.answer = answer;

    }
}
